# Entrega Taller 2 — SEM ECP 2023

Incluye el artículo LaTeX y PDF, bibliografía, diagramas, tablas, scripts 00–04, salidas agregadas y `Taller2_SEM_resultados.xlsx`. No contiene microdatos ni ZIP del DANE.

## Reproducción

Extraiga el ZIP y coloque los ZIP originales en `datos_crudos/`: `Democracia.zip`, `Participacion.zip`, `Capital_social.zip`, `Caracteristicas_generales.zip`, `Caracteriasticas generales 2.zip` y `Tabla de viviendas.zip`. Los scripts leen ZIP crudos porque la base integrada del Taller 1 no trae `FEX_P`; se enlaza desde Tabla de viviendas mediante `DIRECTORIO`.

Ejecute desde la raíz, en orden: `00_preparacion.R`, `01_afc.R`, `02_estructural.R`, `03_multigrupo.R`, `04_exportar_resultados.R`. Versiones reproducidas: R 4.6.1, lavaan 0.7-3, semTools 0.5-9 y writexl 2.0.1.

El PDF tiene 24 páginas (15 de cuerpo). La correlación residual opcional P2025S5–P2025S6 queda para trabajo futuro con calibración y validación en muestras separadas.

Para recompilar el artículo, entre a `articulo/`: `pdflatex articulo.tex`, `bibtex articulo`, y luego `pdflatex articulo.tex` dos veces.
